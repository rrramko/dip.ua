<?php //login.php
/*mysql_select_db("diplom") or die(mysql_error());*/
$db_hostname = 'localhost';
$db_database = 'diplom';
$db_username = 'root';
$db_password = '';

?>